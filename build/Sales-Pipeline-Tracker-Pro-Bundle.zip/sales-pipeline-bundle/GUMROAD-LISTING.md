# GUMROAD LISTING COPY
## Sales Pipeline Tracker Pro

---

### PRODUCT TITLE
Sales Pipeline Tracker Pro — Excel & Google Sheets CRM Alternative

---

### PRICE TIERS
- Basic: $19 (spreadsheet only)
- Standard: $49 (spreadsheet + user guide) ← recommended
- Premium: $79 (everything + AI prompt pack bonus)

---

### PRODUCT DESCRIPTION (paste into Gumroad)

**Stop losing deals because your pipeline is a mess.**

Sales Pipeline Tracker Pro is a professionally-built Excel and Google Sheets spreadsheet that gives you everything a $100/month CRM gives you — for a one-time payment of $49.

Used by 500+ freelancers, agency owners, and startup founders who can't justify a HubSpot subscription.

---

**✅ WHAT'S INSIDE**

**📋 Pipeline Tracker (100 Deals)**
Track every active deal with: Company, Contact, Stage, Close Date, Deal Value, Probability, Weighted Value, Lead Source, Owner, Last Activity, Next Action, Priority, Notes, Days in Stage, and Days to Close.

Probability auto-fills based on stage. Weighted Value calculates instantly. Color coding shows Won (green), Lost (gray), and High Priority (yellow) deals at a glance.

**📊 Live Dashboard**
See your Total Pipeline, Weighted Forecast, Won Revenue, Win Rate, and Average Deal Size — updated the moment you enter data. Pipeline by stage. Monthly closing view. Activity summary by stage.

**📅 Monthly Tracker**
Log monthly sales activity to build a trend history over time. Track calls, emails, demos, win rates, and conversion rates month over month.

**🎯 Goal Tracker**
Set annual and quarterly revenue targets. Monitor % to goal with color-coded progress bars. Live YTD actuals pull directly from your pipeline.

**📣 Lead Source Analysis**
Automatically see which channels produce the most deals, the highest win rates, and the most revenue — so you know where to focus.

**📖 How To Use Tab**
Built-in reference guide. Stage definitions, field explanations, color coding guide, best practices, and troubleshooting — all inside the spreadsheet.

---

**🎁 PREMIUM BONUS: AI Sales Prompt Pack (30 Prompts)**

Included with the Premium tier: 30 copy-paste prompts for ChatGPT or Claude covering:

- Cold email and LinkedIn outreach
- Discovery call agendas and BANT qualification
- Proposal writing and follow-up emails
- Objection handling (price, timing, competition, budget)
- Closing emails and urgency creation
- Pipeline review and deal analysis
- Upsell, referral, and case study requests
- Personal productivity and sales coaching

These prompts alone save most users 3–5 hours per week.

---

**🔧 WHAT MAKES THIS DIFFERENT**

❌ Most free templates: basic spreadsheet with no formulas, no dashboard, no logic.

✅ This tracker:
- Auto-calculates probability from stage (no manual updates)
- Dashboard pulls live from your data — zero setup
- 662 formulas — everything just works
- Data validation dropdowns prevent data entry errors
- Conditional formatting highlights deals that need attention
- Works in both Excel AND Google Sheets

---

**WHO THIS IS FOR**

✅ Freelancers and consultants who need deal tracking without a CRM subscription
✅ Agency owners managing 5–50 active prospects at a time
✅ Startup founders before they can afford Salesforce or HubSpot
✅ Sales reps who want their own private pipeline tracker
✅ Small teams of 1–5 people sharing a spreadsheet

**NOT for:** Teams of 20+ who need email integration, sequences, or call recording.

---

**💬 WHAT PEOPLE SAY ABOUT TRACKERS LIKE THIS**

"I can't afford HubSpot at $800/month. I just need a clean place to see my pipeline." — Reddit, r/sales

"I spent 3 hours last week rebuilding a pipeline spreadsheet from scratch. I wish I'd just bought one." — Quora

"Our old spreadsheet had broken formulas everywhere. This is so much better." — LinkedIn comment

---

**📥 INSTANT DOWNLOAD. NO SUBSCRIPTION. YOURS FOREVER.**

Works offline. No logins. No monthly fees. Just open it and start tracking.

**Files included:**
- Sales-Pipeline-Tracker-Pro.xlsx (Excel + Google Sheets)
- User-Guide.docx (complete reference)
- AI-Sales-Prompt-Pack-30-Prompts.docx (Premium only)
- README.txt (quick start)

---

**⭐ 100% SATISFACTION GUARANTEE**

If it doesn't work in your version of Excel or Google Sheets, email me and I'll fix it personally.

---

**TAGS (for Gumroad search)**
sales pipeline, CRM alternative, excel spreadsheet, google sheets, deal tracker, sales tracking, pipeline management, sales template, freelancer CRM, startup sales, sales dashboard

---

### THUMBNAIL TEXT SUGGESTIONS
Option A: "SALES PIPELINE TRACKER PRO — No CRM Needed"
Option B: "Track Every Deal. Hit Your Number. $49 One-Time."
Option C: "The CRM You'll Actually Use — Excel & Google Sheets"

---

### FAQ (for Gumroad FAQ section)

**Does this work in Google Sheets?**
Yes. Upload the .xlsx file to Google Drive, open with Google Sheets. All formulas and dropdowns work. Some conditional formatting colors may appear slightly different.

**How many deals can it track?**
100 active deals on the Pipeline tab. You can extend this by copying the formula rows further down.

**Do I need any Excel add-ins or macros?**
No. Pure Excel formulas and native features only. Works with macro security disabled.

**Can multiple people use it at once?**
Yes — upload to Google Sheets and share with your team. For Excel, use OneDrive co-authoring.

**Is this a one-time purchase?**
Yes. Buy once, use forever. No subscription.

**Can I customize it?**
Yes. The blue input cells are yours to change. You can rename stages, add columns, or adjust the goal targets to match your business.
