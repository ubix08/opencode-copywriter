━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SALES PIPELINE TRACKER PRO — Thank You for Your Purchase!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT'S INCLUDED:

📁 /product/
   Sales-Pipeline-Tracker-Pro.xlsx
   → The main spreadsheet. Open this first.
   → Works in Microsoft Excel (2016+) and Google Sheets.

📁 /docs/
   User-Guide.docx
   → Complete reference guide for all 6 tabs.
   → Includes daily workflow and troubleshooting.

📁 /bonus/
   AI-Sales-Prompt-Pack-30-Prompts.docx
   → 30 copy-paste prompts for ChatGPT / Claude.
   → Covers prospecting, objections, closing, and more.


QUICK START (2 minutes):

1. Open Sales-Pipeline-Tracker-Pro.xlsx
2. Go to the 📋 Pipeline tab
3. Delete sample data in rows 3-12
4. Start entering your deals in the BLUE cells
5. Check 📊 Dashboard — it updates automatically


COMPATIBILITY:

✅ Microsoft Excel 2016, 2019, 2021, Microsoft 365
✅ Google Sheets (upload via File > Import)
✅ LibreOffice Calc (some conditional formatting may vary)


SUPPORT:

Questions? Email: support@yourstore.com

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
